"""Strategy-owned experience snapshots, shared rewriting, and dependency selection."""
from copy import deepcopy
import json
import re
import time

from jsonschema import validate as validate_json

from . import adapters
from .causal import procedure_schema
from .memory import load, template_variables
from .results import safe_error
from .selection import ROOT, digest, read_json

PROTOCOL = 'strategy_experience_state_v1'


def enabled(config):
    return config.get('memory', {}).get('evolution') is True


def dependencies(entry, catalog):
    return {key: digest(catalog[key]) if key in catalog else None for key in entry['value']['tool_ids']}


def initialize(config, catalog):
    artifact = load(config)
    if artifact['protocol'] != 'verified_tool_recovery_k0_v1' or artifact['catalog'] != catalog:
        raise ValueError('Experience evolution requires verified K0 matching the complete Early catalog')
    source = read_json(ROOT / config['memory']['source'])
    cases = {c['id']: c for c in source['cases']}
    entries = deepcopy(artifact['memories'])
    state = {'protocol': PROTOCOL, 'knowledge_stage': 'original', 'memories': entries,
        'memory_sha256': digest(entries), 'origin_memory_sha256': artifact['memory_sha256'],
        'dependency_hashes': {e['id']: dependencies(e, catalog) for e in entries},
        'origins': {e['id']: {'case_id': e['case_id'], 'tool_ids': e['value']['tool_ids'],
            'evidence_call_ids': e['value']['evidence_call_ids'],
            'observed_call_ids': [c['tool_call_id'] for c in cases[e['case_id']]['trace']],
            'forbidden_constants': cases[e['case_id']]['forbidden_constants']} for e in entries}}
    validate_state(state, catalog)
    return state


def affected(entry, old_catalog, new_catalog):
    if entry.get('adaptation', {}).get('status') == 'unavailable':
        servers = {k.split('::')[0] for k in entry['value']['tool_ids']}
        return ({k:v for k,v in old_catalog.items() if v['server'] in servers} !=
                {k:v for k,v in new_catalog.items() if v['server'] in servers})
    return any(old_catalog.get(k) != new_catalog.get(k) for k in entry['value']['tool_ids'])


def witness(value, schema, variables):
    """Check symbolic call shapes against real schemas without executing or guessing task data."""
    if isinstance(value, str) and '${' in value:
        refs = set(re.findall(r'\$\{([A-Z0-9_]+)\}', value))
        if not refs or not refs <= set(variables) | {'WORKSPACE'}:
            raise ValueError('Unknown variable in experience call template')
        kind = schema.get('type', 'string')
        if isinstance(kind, list):kind = next((k for k in kind if k != 'null'), 'string')
        if kind in ('array', 'object'):
            raise ValueError('Call templates must preserve JSON container types')
        if 'enum' in schema:return schema['enum'][0]
        if 'const' in schema:return schema['const']
        if kind in ('integer', 'number'):return max(1, schema.get('minimum', 1))
        if kind == 'boolean':return True
        if kind == 'null':return None
        return 'x' * max(1, schema.get('minLength', 1))
    if isinstance(value, dict):
        return {k:witness(v, schema.get('properties', {}).get(k, {}), variables) for k,v in value.items()}
    if isinstance(value, list):
        return [witness(v, schema.get('items', {}), variables) for v in value]
    return value


def validate_entry(entry, catalog, origin):
    value = procedure_schema().model_validate(entry['value'], strict=True).model_dump(mode='json', exclude_defaults=True)
    if entry['case_id'] != origin['case_id'] or set(value['evidence_call_ids']) != set(origin['evidence_call_ids']):
        raise ValueError('An update changed its fixed practice provenance')
    if any(t and t in json.dumps(value, ensure_ascii=False) for t in origin['forbidden_constants']):
        raise ValueError('An update retained a private practice constant')
    if entry.get('adaptation', {}).get('status') == 'unavailable':
        return
    if not set(value['tool_ids']) <= set(catalog):
        raise ValueError('Adapted experience refers to unavailable tool IDs')
    if not value.get('tool_call_templates'):
        raise ValueError('Experience rebuilding dropped verified call structures')
    for template in value['tool_call_templates']:
        key = template['tool_id']
        if key not in value['tool_ids'] or not set(template['evidence_call_ids']) <= set(origin['observed_call_ids']):
            raise ValueError('Adapted call template lost its tool/provenance binding')
        schema = catalog[key]['inputSchema']
        validate_json(witness(template['arguments'], schema, template_variables(value)), schema)


def validate_state(state, catalog):
    if state['protocol'] != PROTOCOL or digest(state['memories']) != state['memory_sha256']:
        raise ValueError('Experience snapshot checksum mismatch')
    ids = [e['id'] for e in state['memories']]
    if len(ids) != len(set(ids)) or set(ids) != set(state['origins']):
        raise ValueError('Experience identity set changed')
    for entry in state['memories']:
        validate_entry(entry, catalog, state['origins'][entry['id']])
        if state['dependency_hashes'][entry['id']] != dependencies(entry, catalog):
            raise ValueError('Experience dependency checkpoint mismatch')


def rewrite(config, entry, origin, old_catalog, new_catalog, context, index, emit):
    """The exact same rebuilder is called by Full Rewrite and Selective Patch."""
    if config.get('mode') == 'offline':
        from .testing import rewrite_experience
        return rewrite_experience(entry, new_catalog), {'status':'completed','offline_simulated':True,
            'api_calls':0,'input_tokens':0,'output_tokens':0}
    from .core import make_client
    selected = set(entry['value']['tool_ids'])
    servers = {k.split('::')[0] for k in selected}
    candidates = {k:v for k,v in new_catalog.items() if k in selected}
    if len(candidates) != len(selected) or entry.get('adaptation', {}).get('status') == 'unavailable':
        candidates = {k:v for k,v in new_catalog.items() if v['server'] in servers}
    record_shape = deepcopy(entry['value'])
    message = ('Rebuild this tool-use experience for the target tool contract. Use no benchmark tasks, answers or traces. '
        'Keep the complete value compact, ideally under 2200 characters; do not repeat full tool descriptions. '
        'Preserve entry purpose and EXACT evidence_call_ids; these prove original practice, not target-version execution. '
        'Enumerate every needed target tool ID. Keep call templates, evidence IDs, and template_variables. '
        'Retain working call structures and details when compatible with the new contract. '
        'Preserve actual array/object shapes; use ${UPPERCASE_VARIABLE} only for primitive input/output values and '
        'declare every variable except WORKSPACE. Add newly required arguments, satisfy enums, minItems and lengths; '
        'remove unsupported arguments. Bind source/request IDs from actual returns, not paths or invented constants. '
        'If the operation cannot be represented, return only {"unavailable":true,"reason":"explain why"}. '
        'Otherwise return the procedure DATA object directly, with tool_ids, content, applicability, '
        'failed_assumption, corrective_actions, verification, evidence_call_ids, tool_call_templates and template_variables. '
        'Do not add status/value wrappers or return a JSON Schema. '
        '\nPrevious experience: '+json.dumps(entry['value'],ensure_ascii=False)+
        '\nPrevious dependency contracts: '+json.dumps({k:v for k,v in old_catalog.items() if k in selected},ensure_ascii=False)+
        '\nTarget contracts: '+json.dumps(candidates,ensure_ascii=False)+
        '\nReturn a JSON DATA RECORD, not a JSON Schema, without Markdown. Shape: '+json.dumps(record_shape,ensure_ascii=False))
    journal = {'entry_id':entry['id'],'status':'started','model':config['memory'].get('model',config['agent_model']),
        'messages':[{'role':'user','content':message}],'api_calls':0,'input_tokens':None,'output_tokens':None}
    effective = deepcopy(config)
    providers = config['providers']['agent']
    effective['providers']['agent'] = [providers[(index + context['repeat']) % len(providers)]]
    client = None
    try:
        client = make_client(effective, 'experience_update', emit=emit)
        journal['api_calls'] = 1
        emit({'kind':'experience_update_request','strategy':context['strategy'],'stage':context['stage'],
              'repeat':context['repeat'],'journal':deepcopy(journal)})
        response = client.chat.completions.create(model=journal['model'],messages=journal['messages'],
            temperature=0,max_tokens=config['agent_max_tokens'],response_format={'type':'json_object'})
        journal['response'] = response.model_dump(mode='json')
        if response.usage:
            journal.update(input_tokens=response.usage.prompt_tokens,output_tokens=response.usage.completion_tokens)
        if response.choices[0].finish_reason != 'stop' or getattr(response.choices[0].message,'refusal',None):
            raise ValueError('Experience update was truncated or refused')
        def unique(pairs):
            data={}
            for k,v in pairs:
                if k in data:raise ValueError('Duplicate experience-update JSON key')
                data[k]=v
            return data
        data=json.loads(response.choices[0].message.content or '',object_pairs_hook=unique)
        updated=deepcopy(entry)
        if isinstance(data,dict) and set(data)=={'unavailable','reason'} and data['unavailable'] is True:
            if not isinstance(data['reason'],str) or not data['reason']:
                raise ValueError('Unavailable experience requires a reason')
            status,reason='unavailable',data['reason']
        else:
            updated['value']=procedure_schema().model_validate(data,strict=True).model_dump(mode='json',exclude_defaults=True)
            status,reason='active','Rebuilt from previous experience and target tool contracts'
        updated['adaptation']={'status':status,'reason':reason,'stage':context['stage'],
            'validation':'Target contract only; original practice provenance retained; no target behavior verification'}
        validate_entry(updated,new_catalog,origin)
        journal['status']='completed'
        return updated,journal
    except Exception as exc:
        journal.update(status='failed',error=safe_error(exc))
        exc.experience_journal=journal
        raise
    finally:
        if client is not None:client.close()
        emit({'kind':'experience_update_request','strategy':context['strategy'],'stage':context['stage'],
              'repeat':context['repeat'],'journal':deepcopy(journal)})


def evolve(config, strategy, state, old_catalog, new_catalog, context, emit=lambda event:None, rebuilder=None):
    """Return a whole validated checkpoint, never a partly updated library."""
    started=time.perf_counter()
    old_catalog,new_catalog=adapters.semantic(old_catalog),adapters.semantic(new_catalog)
    if strategy not in ('no_update','full_rewrite','selective_patch'):
        raise ValueError('Unsupported experience strategy')
    report={'strategy':strategy,'status':'updating','scope':'tool-level dependency hashes; all semantic fields',
        'before_sha256':state['memory_sha256'],'entries':[],'requests':[]}
    result=deepcopy(state)
    selected=[] if strategy=='no_update' else [e['id'] for e in state['memories'] if strategy=='full_rewrite' or affected(e,old_catalog,new_catalog)]
    report['selected_ids']=selected
    try:
        for index,entry in enumerate(state['memories']):
            changed=entry['id'] in selected
            updated=deepcopy(entry)
            if changed:
                updated,journal=(rebuilder or rewrite)(config,deepcopy(entry),deepcopy(state['origins'][entry['id']]),
                    deepcopy(old_catalog),deepcopy(new_catalog),{**context,'strategy':strategy},index,emit)
                report['requests'].append(journal)
                if updated['id'] != entry['id']:raise ValueError('Experience entry identity must remain stable')
                validate_entry(updated,new_catalog,state['origins'][entry['id']])
            result['memories'][index]=updated
            report['entries'].append({'id':entry['id'],'rebuilt':changed,'before_sha256':digest(entry),
                'after_sha256':digest(updated),'unchanged_bytes':digest(entry)==digest(updated)})
        if strategy!='no_update':
            result.update(knowledge_stage=context['stage'],memory_sha256=digest(result['memories']),
                dependency_hashes={e['id']:dependencies(e,new_catalog) for e in result['memories']})
            validate_state(result,new_catalog)
        report.update(status='completed',after_sha256=result['memory_sha256'])
    except Exception as exc:
        if getattr(exc,'experience_journal',None):report['requests'].append(exc.experience_journal)
        report.update(status='failed',error=safe_error(exc));result=None
    report['elapsed_seconds']=time.perf_counter()-started
    report['api_calls']=sum(r.get('api_calls',0) for r in report['requests'])
    for key in ('input_tokens','output_tokens'):
        values=[r.get(key) for r in report['requests']]
        report[key]=sum(values) if all(v is not None for v in values) else None
    report.update(api_cost=None if report['api_calls'] else 0,cost_currency=None,
                  cost_basis='Actual update requests; monetary cost unavailable' if report['api_calls'] else 'No model requests')
    return result,report


def as_artifact(state, catalog):
    validate_state(state,catalog)
    return {'protocol':'verified_tool_recovery_k0_v1','catalog':catalog,'memories':deepcopy(state['memories']),
            'memory_sha256':state['memory_sha256']}
