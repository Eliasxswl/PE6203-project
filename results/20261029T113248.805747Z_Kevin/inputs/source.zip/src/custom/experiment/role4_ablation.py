"""Replay Role 4's frozen task-403 plan through the shared experiment writer/runtime."""
from copy import deepcopy
from pathlib import Path

from custom.agents.tool_feedback import reported_error
from .core import run_trajectory
from .counterfactual import FIXED
from .experience_state import validate_state
from .results import Store, SCORES, atomic_json, identity, safe_error, writer_lock, create
from .runtime import ALIASES, policy_for
from .selection import ROOT, digest, file_hash, fingerprints, read_json, tasks

PROTOCOL = 'role4_archived_late_unchanged_memory_ablation_v1'
COMMIT = '4c5637e957e9590bb384028602885e869f33822a'
PLAN_SHA256 = '6b65d658805334fc44a79321c7b50dd0bff2c1adf56d1cb9c6dc4f69c80f6236'
ARMS = ('rewrite_unchanged', 'preserve_unchanged')


def verify(plan):
    payload = deepcopy(plan)
    claimed = payload.pop('plan_sha256', None)
    if claimed != PLAN_SHA256 or digest(payload) != claimed:
        raise ValueError('Use the unchanged, reviewed Role 4 task-403 plan')
    source = ROOT / 'results' / plan['source_run']
    if any(file_hash(source / name) != checksum for name, checksum in plan['source_hashes'].items()):
        raise ValueError('The archived source no longer matches the frozen plan')
    for state in plan['arms'].values():
        validate_state(state, plan['snapshot']['knowledge'])
    return source


def summarize(records):
    output = {'protocol': PROTOCOL, 'status': records['status'], 'conditions': {}, 'paired': []}
    rows = records['trajectories']
    for arm in ARMS:
        group = [r for r in rows.values() if r['identity']['strategy'] == arm]
        good = [r for r in group if r.get('score') is not None]
        errors = [c for r in group for c in r['raw_tool_trace']
                  if reported_error(c.get('semantic_identity'), c['response'])]
        output['conditions'][arm] = {
            'planned': len(group), 'completed_agents': sum(r['agent_status'] == 'completed' for r in group),
            'scored': len(good), 'valid_judge_slots': sum(a['status'] == 'completed' for r in group for a in r['judge_attempts']),
            'means': {m: sum(r['score'][m] for r in good) / len(good) if good else None for m in SCORES},
            'tool_error_calls': len(errors), 'schema_error_calls': sum(bool(c.get('harness_schema_feedback')) for c in errors),
            'stop_reasons': [r.get('stop_reason') for r in group]}
    for repeat in range(3):
        pair = {a: rows[identity(a, 'iter5', 403, repeat)] for a in ARMS}
        if all(r.get('score') is not None for r in pair.values()):
            output['paired'].append({'repeat': repeat, 'scores': {a: r['score'] for a, r in pair.items()},
                'tf_rewrite_minus_preserve': pair[ARMS[0]]['score']['task_fulfillment'] - pair[ARMS[1]]['score']['task_fulfillment'],
                'fully_judged': all(a['status'] == 'completed' for r in pair.values() for a in r['judge_attempts'])})
    pairs = output['paired']
    output['fully_judged_pairs'] = sum(p['fully_judged'] for p in pairs)
    output['mean_tf_rewrite_minus_preserve'] = sum(p['tf_rewrite_minus_preserve'] for p in pairs) / len(pairs) if pairs else None
    runtimes = [e['runtime_id'] for e in records['events'] if e['kind'] == 'runtime_prepared']
    output['distinct_runtime_ids'] = len(runtimes) == len(set(runtimes))
    output['interpretation'] = ('Fixed archived Middle-to-Late intervention. Negative paired differences support detrimental rewriting '
                                'in these contexts; do not infer causality from a single stochastic outcome. Missing observations stay missing.')
    return output


def run(config, plan_path):
    plan = read_json((ROOT / Path(plan_path)).resolve())
    source = verify(plan)
    if any(config.get(k) != plan['settings'].get(k) for k in FIXED):
        raise ValueError('Preserve the reviewed model, memory, runtime and evaluation settings')
    effective = deepcopy(plan['settings'])
    effective.update(mode=config.get('mode', 'live'), strategies=list(ARMS), agent_repeats=3)
    if tasks(effective) != plan['tasks']:
        raise ValueError('The original task selection changed')
    if effective['mode'] == 'live':
        for server in plan['task']['servers']:
            policy = policy_for(ALIASES.get(server, server), effective)
            if policy.get('concurrency') != 'private' or policy.get('external_mutation'):
                raise ValueError('The ablation requires private local task backends')
    expected = fingerprints(effective)
    path = create(effective, [plan['task']], expected, False, 1)
    with writer_lock(path):
        store = Store(path)
        store.records.update(status='running', episodes={}, initial_snapshot=deepcopy(plan['initial_snapshot']))
        store.records['trajectories'] = {k: r for k, r in store.records['trajectories'].items() if r['identity']['stage'] == 'iter5'}
        store.manifest.update(harness_protocol=PROTOCOL, purpose='task403_middle_to_late_unchanged_memory_ablation',
            shared_early=None, prompt_time=plan['prompt_time'], task_annotations={},
            logical_conditions=[r['identity'] for r in store.records['trajectories'].values()],
            planned_jobs=[r['identity'] for r in store.records['trajectories'].values()],
            diagnostic={'source_commit': COMMIT, 'plan_sha256': plan['plan_sha256'], 'source_hashes': plan['source_hashes'],
                'affected_entry_ids': plan['affected_entry_ids'], 'unaffected_entry_ids': plan['unaffected_entry_ids'],
                'updater_calls': 0, 'order': 'AB, BA, AB; serial; same account_four in every trial'},
            analysis={'comparison': 'Late FR versus the same Late affected entries plus Middle unaffected entries; no ECS'})
        atomic_json(path / 'experiment.json', store.manifest)
        atomic_json(path / 'inputs/ablation-plan.json', plan)
        store.save()
        print('Role 4 ablation:', path, flush=True)
        try:
            for repeat in range(3):
                for arm in (ARMS if repeat % 2 == 0 else ARMS[::-1]):
                    if fingerprints(effective) != expected:
                        raise ValueError('Experimental inputs changed before a trial')
                    run_trajectory({'config': effective, 'tasks': plan['tasks'], 'task': plan['task'], 'stage': 'iter5',
                        'strategy': arm, 'repeat': repeat, 'snapshot': deepcopy(plan['snapshot']),
                        'knowledge': deepcopy(plan['snapshot']['knowledge']), 'experience_state': deepcopy(plan['arms'][arm]),
                        'initial_snapshot': deepcopy(plan['initial_snapshot']), 'records': store.records['trajectories'],
                        'prompt_time': plan['prompt_time']}, store.apply)
                    store.save()
            rows = list(store.records['trajectories'].values())
            failed = any(r['status'] != 'completed' or r.get('score') is None for r in rows)
            warnings = any(a['status'] != 'completed' for r in rows for a in r['judge_attempts'])
            store.records['status'] = 'completed_with_failures' if failed else 'completed_with_warnings' if warnings else 'completed'
        except BaseException as exc:
            store.records['status'] = 'interrupted' if isinstance(exc, KeyboardInterrupt) else 'failed'
            store.event('ablation_stopped', error=safe_error(exc))
            store.recover(reason='ablation_stopped')
            raise
        finally:
            if fingerprints(effective) != expected or any(file_hash(source / name) != h for name, h in plan['source_hashes'].items()):
                store.records['status'] = 'invalidated_inputs_changed'
                for row in store.records['trajectories'].values():
                    row.update(score=None, score_exclusion_reason='experimental_inputs_changed')
            store.save()
            result = summarize(store.records)
            atomic_json(path / 'summary.json', result)
        return path, result
