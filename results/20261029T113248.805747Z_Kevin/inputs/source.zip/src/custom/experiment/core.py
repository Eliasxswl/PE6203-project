"""One ordered strategy/repeat episode; shared by serial and spawn execution."""
from copy import deepcopy
import json
import os
import random
import time

from . import adapters
from .errors import Cancelled, CheckpointFailure, ExecutionFailure
from .judge_output import contract as judge_contract, parse as parse_judge_output, request_options, validate_completion
from .results import PROTOCOL, SCORES, TERMINAL, episode_id, identity, redact, safe_error, utc_now
from .runtime import ALIASES, LiveRuntime
from .selection import STAGES, digest, provider_for, request_limit


def runtime_for(config, stage, servers, task_list, cancel, owner_callback=None):
    if config.get("mode") == "offline":
        from .testing import OfflineRuntime
        return OfflineRuntime(config, stage, servers, cancel, task_list)
    return LiveRuntime(config, stage, servers, cancel, owner_callback)


def workspace_observation(workspace):
    """Optional diagnostic evidence; never expose these readbacks to the agent."""
    from .selection import file_hash
    files = {}
    for path in sorted(workspace.rglob('*')):
        if not path.is_file():
            continue
        name = path.relative_to(workspace).as_posix()
        item = {'sha256': file_hash(path), 'bytes': path.stat().st_size}
        if path.suffix.lower() in ('.json', '.md', '.txt', '.yml', '.yaml') and item['bytes'] <= 262144:
            try:
                item['text'] = path.read_text(encoding='utf-8')
            except UnicodeError:
                pass
        files[name] = item
    return files


def make_client(config, key, cancel=None, emit=None, role="agent"):
    if config.get("mode") == "offline":
        from .testing import OfflineClient
        return OfflineClient(config, key)
    import httpx
    from openai import OpenAI
    from custom.utils import model_config
    provider = provider_for(config, role, key)
    credential = model_config.role_api_key(role, provider)
    endpoint = model_config.role_base_url(role, provider)
    timeout = httpx.Timeout(config["runtime"]["model_timeout"], connect=config["runtime"]["connect_timeout"])
    options = {}
    if config['runtime'].get('model_connect_retries', 0):
        from .connection_transport import client as connection_client
        options['http_client'] = connection_client(timeout, config['runtime']['model_connect_retries'],
            (lambda event: emit({**event, 'request_key':key, 'role':role})) if emit else None)
    client = OpenAI(api_key=credential, base_url=endpoint, max_retries=0, timeout=timeout, **options)
    if config.get("request_policy"):
        from .rate_limit import ControlledClient
        event_sink = (lambda event: emit({**event, "request_key": key,
            "quota_group": provider.get("quota_group", "default"), "role": role})) if emit else None
        return ControlledClient(client, config, endpoint, credential, cancel, event_sink,
                                quota_group=provider.get("quota_group", "default"))
    return client


def judge_prompt(task, row, catalog, order):
    from custom.analysis.answer.evaluation import messages_to_string, truncate_tool_content
    from custom.prompt.eval_error_prompt import build_mcp_bench_judge_prompt
    from custom.utils.test_utils import format_tools_to_string
    descriptions = ""
    for original in task["servers"]:
        server = ALIASES.get(original, original)
        current = [{**tool, "name": key} for key, tool in catalog.items() if tool["server"] == server]
        descriptions += f"Tools for Server - {original}: \n{format_tools_to_string(current)}\n\n"
    visible = truncate_tool_content(row["trajectory_messages"])[2:]
    for message in visible:
        if message.get("tool_calls"):
            message["tool_calls"] = deepcopy(message["tool_calls"])
            for call in message["tool_calls"]:
                function = call.get("function", {})
                name = function.get("name")
                if name is not None:
                    function["name"] = row.get("tool_identities", {}).get(name, name)
    trajectory = messages_to_string(visible)
    return build_mcp_bench_judge_prompt(task["question"], descriptions, trajectory, row["answer"], dimension_order=tuple(order))


def request_judge(client, config, prompt):
    """Shared formal/diagnostic request; serialization is separate from rubric."""
    return client.chat.completions.create(**request_options(config, prompt))


def parse_judge(raw, config=None):
    return parse_judge_output(raw, config)


def initial_snapshot(config, task_list, emit):
    """Freeze one Early catalog for every strategy/repeat, without model calls."""
    snapshot = {"status": "updating", "before": {}, "catalog": {}, "errors": {}}
    emit({"kind": "initial_snapshot", "snapshot": snapshot})
    servers = sorted({ALIASES.get(s, s) for task in task_list for s in task["servers"]})
    for server in servers:
        try:
            with runtime_for(config, "original", [server], task_list, None,
                             lambda event: emit({**event, "episode": "initial"})) as runtime:
                snapshot["catalog"].update(runtime.catalog)
        except Exception as exc:
            snapshot["errors"][server] = safe_error(exc)
    snapshot.update(status="ready", knowledge=adapters.semantic(snapshot["catalog"]),
                    changed_entries=sorted(snapshot["catalog"]),
                    explanation="Shared frozen Early knowledge; each episode receives a defensive copy",
                    elapsed_seconds=0.0, **adapters.no_model_usage())
    from .experience_state import enabled as experience_enabled, initialize as initialize_experience
    if experience_enabled(config):
        if snapshot['errors']:
            raise ExecutionFailure('Cannot initialize experience evolution with an incomplete Early catalog')
        snapshot['experience_state'] = initialize_experience(config, snapshot['knowledge'])
    emit({"kind": "initial_snapshot", "snapshot": snapshot})
    return snapshot


def run_episode(spec, emit, cancel=None, dispatch=None):
    config, task_list = spec["config"], spec["tasks"]
    strategy, repeat = spec["strategy"], spec["repeat"]
    eid = episode_id(strategy, repeat)
    snapshots = deepcopy(spec["episode"]["stages"])
    rows = deepcopy(spec["records"])
    adapters.load_plugins(config)
    knowledge, previous, experience = {}, {}, None

    def check_cancel():
        if cancel and cancel.is_set():
            raise Cancelled()

    def send(event):
        check_cancel()
        event.setdefault("episode", eid)
        try:
            emit(redact(event))
        except (Cancelled, CheckpointFailure):
            raise
        except BaseException as exc:
            raise CheckpointFailure("Durable writer unavailable") from exc

    def save_row(key, row):
        row["updated_at"] = utc_now()
        send({"kind": "trajectory", "key": key, "record": row})

    send({"kind": "episode", "episode": eid, "status": "preparing" if spec.get('prepare_only') else "running"})
    for stage in STAGES:
        check_cancel()
        snapshot = snapshots.get(stage)
        if stage == "original" and snapshot is None:
            snapshot = deepcopy(spec["initial_snapshot"])
            send({"kind": "stage", "episode": eid, "stage": stage, "snapshot": snapshot})
            snapshots[stage] = deepcopy(snapshot)
        if snapshot is None:
            snapshot = {"status": "updating", "before": deepcopy(knowledge), "catalog": {}, "errors": {}}
            send({"kind": "stage", "episode": eid, "stage": stage, "snapshot": snapshot})
            # One service per server allows catalog failures to affect only dependent tasks.
            servers = sorted({ALIASES.get(s, s) for t in task_list for s in t["servers"]})
            for server in servers:
                check_cancel()
                try:
                    with runtime_for(config, stage, [server], task_list, cancel, send) as runtime:
                        snapshot["catalog"].update(runtime.catalog)
                except Exception as exc:
                    snapshot["errors"][server] = safe_error(exc)
            try:
                snapshot["catalog"] = adapters.stage_catalog(snapshot["catalog"], config, stage)
                snapshot["evolution_files"] = config["runtime"].get("evolution_files", {}).get(stage, [])
                if stage == "original":
                    result = {"knowledge": adapters.semantic(snapshot["catalog"]),
                              "changed_entries": sorted(snapshot["catalog"]),
                              "explanation": "Independent Early initial knowledge", "elapsed_seconds": 0.0,
                              **adapters.no_model_usage()}
                else:
                    result = adapters.update(strategy, knowledge, previous, snapshot["catalog"],
                                             {"stage": stage, "repeat": repeat})
                    from .experience_state import enabled as experience_enabled, evolve as evolve_experience
                    if experience_enabled(config):
                        if snapshot['errors']:
                            raise ExecutionFailure('Cannot update experience against an incomplete target catalog')
                        next_experience, audit = evolve_experience(config, strategy, experience, previous,
                            snapshot['catalog'], {'stage':stage,'repeat':repeat,
                                'budget_path':spec.get('update_budget_path')}, send)
                        result.update(experience_state=next_experience, experience_update=audit)
                        for field in ('elapsed_seconds','api_calls','input_tokens','output_tokens'):
                            left,right=result.get(field),audit.get(field)
                            result[field]=left+right if left is not None and right is not None else None
                        result.update(api_cost=audit['api_cost'],cost_currency=audit['cost_currency'],
                                      cost_basis='Catalog and experience update: '+audit['cost_basis'])
                        if next_experience is None:
                            snapshot.update(result)
                            raise ExecutionFailure('Experience update failed; no partial knowledge checkpoint committed')
                snapshot.update(status="ready", **result)
            except Exception as exc:
                snapshot.update(status="failed", error=safe_error(exc))
            send({"kind": "stage", "episode": eid, "stage": stage, "snapshot": snapshot})
            snapshots[stage] = deepcopy(snapshot)
        if snapshot["status"] == "ready":
            knowledge = deepcopy(snapshot["knowledge"])
            previous = deepcopy(snapshot["catalog"])
            experience = deepcopy(snapshot.get('experience_state'))
            if spec.get('prepare_only') and experience is not None:
                from .experience_state import as_artifact as experience_artifact
                from .memory import render as render_memory
                from .selection import ROOT
                artifact = experience_artifact(experience, knowledge)
                sizes=[]
                for task in task_list:
                    required={ALIASES.get(s,s) for s in task['servers']}
                    tools,_=adapters.agent_tools(knowledge,snapshot['catalog'],required)
                    context,_=render_memory(config,knowledge,required,ROOT/'.runtime/r/0000000000000000/workspace',
                        api_names={t['meta']['benchmark_semantic_identity']:t['name'] for t in tools},artifact=artifact)
                    sizes.append(len(context))
                snapshot['experience_context_check']={'tasks':len(sizes),'maximum_characters':max(sizes,default=0)}
                send({'kind':'stage','episode':eid,'stage':stage,'snapshot':snapshot})
        else:
            # Never silently reuse or substitute a failed strategy update.
            for task in task_list:
                key = identity(strategy, stage, task["idx"], repeat)
                row = rows[key]
                if row["status"] == "pending":
                    row.update(status="execution_failed", agent_status="failed", score_exclusion_reason="knowledge_update_failed")
                    row["errors"].append(snapshot.get("error", {"type": "KnowledgeFailure", "message": "No valid knowledge snapshot"}))
                    for attempt in row["judge_attempts"]:
                        attempt["status"] = "not_attempted"
                    save_row(key, row)
            # Dependent later transitions cannot start from an uncommitted snapshot.
            for later in STAGES[STAGES.index(stage) + 1:]:
                snapshots[later] = {"status": "failed", "error": {"type": "KnowledgeFailure", "message": "Previous transition failed"}}
                send({"kind": "stage", "episode": eid, "stage": later, "snapshot": snapshots[later]})
            continue
        jobs = [{**spec, "task": task, "stage": stage, "snapshot": deepcopy(snapshot),
                 "knowledge": deepcopy(knowledge), "experience_state": deepcopy(experience), "records": rows} for task in task_list
                if not rows[identity(strategy, stage, task["idx"], repeat)].get("shared_from")]
        if dispatch is None:
            for job in jobs:
                run_trajectory(job, send, cancel)
        else:
            dispatch(jobs)
    send({"kind": "episode", "episode": eid, "status": "prepared" if spec.get('prepare_only') else "completed"})


def run_trajectory(spec, emit, cancel=None):
    config, task_list = spec["config"], spec["tasks"]
    task, stage = spec["task"], spec["stage"]
    strategy, repeat = spec["strategy"], spec["repeat"]
    eid = episode_id(strategy, repeat)
    snapshot, knowledge = spec["snapshot"], spec["knowledge"]
    rows = deepcopy(spec["records"])

    def check_cancel():
        if cancel and cancel.is_set():
            raise Cancelled()

    def send(event):
        check_cancel()
        event.setdefault("episode", eid)
        try:
            emit(redact(event))
        except (Cancelled, CheckpointFailure):
            raise
        except BaseException as exc:
            raise CheckpointFailure("Durable writer unavailable") from exc

    def save_row(key, row):
        row["updated_at"] = utc_now()
        send({"kind": "trajectory", "key": key, "record": row})

    check_cancel()
    key = identity(strategy, stage, task["idx"], repeat)
    row = rows[key]
    if row.get("shared_from"):
        return
    if row["status"] in TERMINAL:
        return
    client = None
    agent = None
    controlled_directory = None
    runtime_context = None
    started = time.perf_counter()
    try:
        if row["agent_status"] != "completed":
            row["agent_worker_pid"] = os.getpid()
            row.update(status="running", agent_status="running", started_at=utc_now(),
                       request_limit=request_limit(config, task), knowledge_sha256=digest(knowledge), harness_protocol=PROTOCOL)
            save_row(key, row)
            required = {ALIASES.get(s, s) for s in task["servers"]}
            unavailable = required & snapshot["errors"].keys()
            unavailable |= required & spec["initial_snapshot"]["errors"].keys()
            if unavailable:
                raise ExecutionFailure("Unavailable task servers: " + ", ".join(sorted(unavailable)))
            row["phase"] = "runtime_startup"
            startup_at = time.perf_counter()
            runtime_context = runtime_for(config, stage, required, task_list, cancel, send)
            if spec.get('controlled_runtime_directory'):
                from pathlib import Path
                from .selection import ROOT
                directory = Path(spec['controlled_runtime_directory']).resolve()
                if directory.parent != (ROOT / '.runtime/r').resolve() or directory.exists():
                    raise ExecutionFailure('Controlled diagnostic directory must be a fresh direct runtime child')
                runtime_context.directory = directory
                if hasattr(runtime_context, 'workspace'):
                    runtime_context.workspace = directory / 'workspace'
                controlled_directory = directory
            with runtime_context as runtime:
                row["runtime_startup_seconds"] = time.perf_counter() - startup_at
                if spec.get('observe_workspace'):
                    row['workspace_observations'] = [workspace_observation(runtime.workspace)]
                # Reject catalog drift between stage discovery and trajectory reset.
                expected = {k: v for k, v in snapshot["catalog"].items() if v["server"] in required}
                current = adapters.stage_catalog(runtime.catalog, config, stage)
                if adapters.semantic(expected) != adapters.semantic(current):
                    raise ExecutionFailure("Tool catalog changed after the stage checkpoint")
                client = make_client(config, key, cancel, send)
                tools, routing = adapters.agent_tools(knowledge, runtime.catalog, required)
                row["tool_identities"] = {tool["name"]: tool["meta"]["benchmark_semantic_identity"] for tool in tools}
                if not tools:
                    raise ExecutionFailure("No initial semantic knowledge is available for this task")

                def on_agent_event(kind, payload):
                    check_cancel()
                    if kind == "model_start":
                        row["phase"] = "agent_model"
                        row["trajectory_messages"] = deepcopy(payload["messages"])
                        row["agent_attempts"].append({"status": "started", "started_at": utc_now()})
                        if spec.get('observe_workspace') and payload.get('request'):
                            row['agent_attempts'][-1]['request'] = deepcopy(payload['request'])
                    elif kind == "model_completed":
                        row["agent_attempts"][-1].update(status="completed", response=payload, completed_at=utc_now())
                    elif kind == "model_failed":
                        row["agent_attempts"][-1].update(status="outcome_unknown" if payload.get("unknown_outcome") else "failed",
                                                         error=payload, completed_at=utc_now())
                    elif kind == "tool_completed":
                        row.update(deepcopy(payload))
                        row["tool_attempts"][-1].update(status="completed", completed_at=utc_now())
                        if spec.get('observe_workspace'):
                            row['workspace_observations'].append(workspace_observation(runtime.workspace))
                    elif kind == "tool_start":
                        row["phase"] = "tool"
                        row["trajectory_messages"] = deepcopy(payload["messages"])
                        row["tool_attempts"].append({"status": "started", "started_at": utc_now(),
                            "name": payload["name"], "arguments": payload["arguments"],
                            "tool_call_id": payload["tool_call_id"]})
                    elif kind == "tool_failed":
                        row["tool_attempts"][-1].update(status="outcome_unknown" if payload.get("unknown_outcome") else "failed",
                                                        error=payload, completed_at=utc_now())
                    elif kind == 'memory_activated':
                        row.setdefault('memory_activations', []).append(deepcopy(payload))
                        exposure = row['memory_exposure']
                        exposure.setdefault('static_selected_ids', deepcopy(exposure['selected_ids']))
                        exposure['selected_ids'] = sorted(set(exposure['selected_ids']) | set(payload['selected_ids']))
                        exposure['recovery_selected_ids'] = sorted({v for a in row['memory_activations'] for v in a['selected_ids']})
                        exposure['recovery_activation_count'] = len(row['memory_activations'])
                    save_row(key, row)

                if config.get('agent_backend') == 'langchain':
                    from custom.agents.LangChainAgent import ChatModel
                else:
                    from custom.agents.SimpleOpenAIAgent import ChatModel
                from custom.utils.test_utils import generate_tree_string
                agent = ChatModel(model_name=config["agent_model"], client=client, tools=tools,
                                  max_round=row["request_limit"], tool_server_map=routing,
                                  file_exists=generate_tree_string(str(runtime.workspace)), workspace_root=runtime.workspace,
                                  prompt_time=spec["prompt_time"], temperature=config["agent_temperature"],
                                  max_new_tokens=config["agent_max_tokens"], tool_caller=runtime.call,
                                  event_callback=on_agent_event, mcp_server_url=runtime.url,
                                  thinking=config.get("agent_thinking"), record_requests=spec.get('observe_workspace',False))
                row['agent_backend'] = config.get('agent_backend', 'legacy')
                if hasattr(agent, 'dependency_versions'):
                    row['agent_dependency_versions'] = agent.dependency_versions
                if 'memory' in config:
                    from .memory import render as render_memory
                    from .experience_state import enabled as experience_enabled, as_artifact as experience_artifact
                    artifact = None
                    if experience_enabled(config):
                        if spec.get('experience_state') is None:
                            raise ExecutionFailure('Missing strategy-owned experience snapshot')
                        artifact = experience_artifact(spec['experience_state'], knowledge)
                        row.update(experience_state_sha256=digest(spec['experience_state']),
                            experience_memory_sha256=artifact['memory_sha256'],
                            experience_knowledge_stage=spec['experience_state']['knowledge_stage'],
                            harness_knowledge_sha256=digest({'catalog':knowledge,'experience':spec['experience_state']}))
                    context, exposure = render_memory(config, knowledge, required, runtime.workspace,
                        api_names={tool['meta']['benchmark_semantic_identity']: tool['name'] for tool in tools}, artifact=artifact)
                    row['memory_exposure'] = exposure
                    agent.messages[0]['content'] += context
                    if config.get('memory', {}).get('profile') == 'error_triggered':
                        if config.get('agent_backend') != 'langchain':
                            raise ValueError('Triggered recovery requires the official LangChain loop')
                        from .recovery_context import configure as configure_recovery
                        agent.recovery = configure_recovery(config, tools, runtime.workspace, len(context), on_agent_event)
                    save_row(key, row)
                answer, messages, stop, exceeded = agent.run_with_server(task["question"])
                if spec.get('observe_workspace'):
                    row['workspace_observations'].append(workspace_observation(runtime.workspace))
                row.update(answer=answer, trajectory_messages=messages, raw_tool_trace=agent.raw_tool_trace,
                           stop=stop, exceeded=exceeded, stop_reason=agent.stop_reason,
                           agent_usage=agent.model_usage, request_count=agent.request_count,
                           agent_elapsed_seconds=agent.elapsed_seconds)
                if agent.execution_error:
                    row["errors"].append(agent.execution_error)
                    raise ExecutionFailure("Agent execution failed; see recorded request/transport error")
            row["agent_status"] = "completed"
            row["judge_catalog"] = deepcopy(expected)
            save_row(key, row)
        if spec.get("phase") == "agent":
            if spec.get('actor_only'):
                row['status'] = 'completed'
                for attempt in row['judge_attempts']:
                    attempt['status'] = 'not_attempted_diagnostic'
            row["elapsed_seconds"] = row.get("elapsed_seconds", 0) + time.perf_counter() - started
            save_row(key, row)
            return
        if client is not None:
            client.close()
        client = make_client(config, key + "/judge", cancel, send, role="judge")
        row["judge_worker_pid"] = os.getpid()
        for attempt in row["judge_attempts"]:
            check_cancel()
            if attempt["status"] != "pending":
                continue
            seed = int(digest([config["selection_seed"], stage, task["idx"], repeat, attempt["slot"]])[:16], 16)
            order = random.Random(seed).sample([0, 1, 2], 3)
            prompt = judge_prompt(task, row, row["judge_catalog"], order)
            attempt.update(status="started", dimension_order=order, started_at=utc_now(), output_contract=judge_contract(config))
            row["phase"] = "judge"
            save_row(key, row)
            judge_started = time.perf_counter()
            try:
                if attempt["slot"] in config.get("mock", {}).get("judge_fail_slots", []) and config["mode"] == "offline":
                    raise ExecutionFailure("Injected judge failure")
                response = request_judge(client, config, prompt)
                raw = response.choices[0].message.content or ""
                attempt.update(raw=raw, usage=response.usage.model_dump() if response.usage else None,
                               finish_reason=response.choices[0].finish_reason)
                validate_completion(response, config)
                result = parse_judge(raw, config)
                attempt.update(status="completed", result=result)
            except Exception as exc:
                error = safe_error(exc)
                attempt.update(status="outcome_unknown" if error["unknown_outcome"] else "failed", error=error)
            attempt.update(elapsed_seconds=time.perf_counter() - judge_started, completed_at=utc_now())
            save_row(key, row)
        good = [a["result"] for a in row["judge_attempts"] if a["status"] == "completed"]
        row.update(status="completed", score={s: sum(a[s] for a in good) / len(good) for s in SCORES} if good else None)
        if not good:
            row["score_exclusion_reason"] = "no_valid_judge_attempts"
    except Exception as exc:
        row.update(status="execution_failed", agent_status="failed", score_exclusion_reason="execution_failure")
        row["errors"].append(safe_error(exc))
        if agent is not None:
            row.update(trajectory_messages=deepcopy(agent.messages), raw_tool_trace=deepcopy(agent.raw_tool_trace))
        for attempt in row["judge_attempts"]:
            if attempt["status"] == "pending":
                attempt["status"] = "not_attempted"
    finally:
        if controlled_directory is not None and controlled_directory.exists():
            # Live runtimes retain small service diagnostics after state cleanup.
            # Move only this stopped owned directory so the paired arm can build
            # the exact same visible path from fresh fixtures.
            import uuid
            proc = getattr(runtime_context, 'proc', None)
            if getattr(runtime_context, 'registered', False) or (proc is not None and proc.poll() is None):
                row['errors'].append({'phase':'paired_runtime_archive','message':'Refused to move a live runtime'})
            else:
                target = controlled_directory.with_name(uuid.uuid4().hex[:16])
                if target.parent.resolve() != controlled_directory.parent.resolve() or target.exists():
                    raise ExecutionFailure('Invalid paired diagnostic archive path')
                controlled_directory.rename(target)
                row['runtime_diagnostics_directory'] = str(target)
        if client is not None:
            try:
                client.close()
            except Exception as exc:
                row["errors"].append({"phase": "client_cleanup", **safe_error(exc)})
        if controlled_directory is not None:
            save_row(key, row)
    row["elapsed_seconds"] = row.get("elapsed_seconds", 0) + time.perf_counter() - started
    save_row(key, row)
