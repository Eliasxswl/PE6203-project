"""Frozen Late-only memory interventions; never regenerate knowledge or alter formal results."""
from contextlib import ExitStack
from copy import deepcopy
import json
from pathlib import Path

from . import adapters
from .core import run_trajectory, runtime_for
from .experience_state import affected, dependencies, validate_state
from .results import Store, atomic_json, create, identity, safe_error, writer_lock
from .runtime import ALIASES, policy_for
from .selection import ROOT, digest, file_hash, fingerprints, read_json

PROTOCOL = 'frozen_memory_counterfactual_v1'
CONDITIONS = ('fr_all', 'fr_changed_only', 'frozen_k0')
STAGE = 'iter5'
FIXED = ('agent_model', 'judge_model', 'agent_temperature', 'judge_temperature', 'agent_max_tokens',
         'judge_max_tokens', 'agent_thinking', 'judge_thinking', 'judge_output_mode', 'round_policy',
         'judge_attempts_per_trajectory', 'automatic_api_retries', 'judge_failure_top_up', 'agent_backend',
         'max_requests', 'selection_seed', 'memory', 'runtime')


def scope(catalog, task):
    servers = {ALIASES.get(s, s) for s in task['servers']}
    return adapters.semantic({k: v for k, v in catalog.items() if v['server'] in servers})


def conditions(records, repeat, restore_entries=None):
    if f'full_rewrite/{repeat}' not in records['episodes']:
        raise ValueError('Snapshot repeat is not present in the archived Full Rewrite run')
    stages = records['episodes'][f'full_rewrite/{repeat}']['stages']
    if any(stages[s]['status'] != 'ready' for s in ('original', STAGE)):
        raise ValueError('Counterfactual requires committed source checkpoints')
    initial, late = stages['original'], stages[STAGE]
    old, target = initial['knowledge'], late['knowledge']
    k0, full = initial['experience_state'], late['experience_state']
    validate_state(k0, old);validate_state(full, target)
    old_entries = {e['id']:e for e in k0['memories']}
    selected = {e['id'] for e in k0['memories'] if affected(e, old, target)}
    restored = set(old_entries) - selected if restore_entries is None else set(restore_entries)
    if not restored <= set(old_entries) - selected:
        raise ValueError('Restore only existing entries whose tool contracts are unchanged')
    hybrid = deepcopy(full)
    hybrid['memories'] = [deepcopy(old_entries[e['id']] if e['id'] in restored else e) for e in full['memories']]
    hybrid['memory_sha256'] = digest(hybrid['memories'])
    hybrid['dependency_hashes'] = {e['id']:dependencies(e, target) for e in hybrid['memories']}
    validate_state(hybrid, target)
    return {'fr_all':(deepcopy(full),deepcopy(target)),
            'fr_changed_only':(hybrid,deepcopy(target)),
            'frozen_k0':(deepcopy(k0),deepcopy(old))}, deepcopy(late), sorted(selected)


def order_control(variant):
    """Change JSON object-key presentation only; every value and list order stays fixed."""
    def reverse_keys(value):
        if isinstance(value, dict):
            return {key:reverse_keys(value[key]) for key in reversed(value)}
        if isinstance(value, list):
            return [reverse_keys(item) for item in value]
        return value
    state, knowledge = deepcopy(variant)
    for entry in state['memories']:
        entry['value'] = reverse_keys(entry['value'])
    if (state, knowledge) != variant:
        raise ValueError('Order control changed knowledge semantics')
    validate_state(state, knowledge)
    return state, knowledge


def native_anchor_directory(anchor, records, key, source, source_hash, task_ids, repeat, config, full_state):
    """Accept an actual formal-rerun trajectory only with its exact donor and settings."""
    diagnostic = anchor.get('diagnostic', {})
    if (anchor.get('purpose') != 'single_original_task_rerun_with_frozen_formal_strategy_snapshots' or
            Path(diagnostic.get('source_experiment', '')).resolve() != source or
            diagnostic.get('source_records_sha256') != source_hash or
            any(anchor['settings'].get(k) != config.get(k) for k in FIXED)):
        raise ValueError('Native input anchor must preserve the exact formal donor and settings')
    row = records['trajectories'].get(key, {})
    expected = {'strategy':'full_rewrite','stage':STAGE,'task_id':task_ids[0],'repeat':repeat}
    if (len(task_ids) != 1 or row.get('identity') != expected or row.get('agent_status') != 'completed' or
            row.get('experience_state_sha256') != digest(full_state)):
        raise ValueError('Native anchor must be the selected completed FR trajectory and snapshot')
    calls = row.get('raw_tool_trace', [])
    if not calls or calls[0].get('semantic_identity') != '@modelcontextprotocol/server-filesystem::search_files':
        raise ValueError('Native anchor requires an observed filesystem workspace path')
    workspace = Path(json.loads(calls[0]['arguments'])['path']).resolve()
    directory = workspace.parent
    root = (ROOT / '.runtime/r').resolve()
    if workspace.name != 'workspace' or directory.parent != root or len(directory.name) != 16:
        raise ValueError('Native anchor path is outside the private runtime root')
    system = row.get('trajectory_messages', [{}])[0].get('content', '')
    if workspace.as_posix() not in system:
        raise ValueError('Native anchor workspace differs from the actual actor input')
    lifecycle = [e['kind'] for e in records['events'] if e.get('runtime_id') == directory.name
                 and e['kind'] in ('runtime_started','runtime_stopped')]
    if not lifecycle or lifecycle[-1] != 'runtime_stopped':
        raise ValueError('Native anchor runtime has not been recorded as stopped')
    return directory


def screening(records):
    """Prioritize observed regressions; these classifications do not assert causality."""
    rows = records['trajectories'];result=[]
    for key, row in rows.items():
        i=row['identity']
        if i['strategy'] not in ('full_rewrite','selective_patch') or i['stage'] not in ('iter3',STAGE):continue
        baseline=rows.get(identity('no_update',i['stage'],i['task_id'],i['repeat']),{})
        if row.get('score') is None or baseline.get('score') is None:continue
        if row['score']['task_fulfillment']>4 or baseline['score']['task_fulfillment']<8:continue
        stages=records['episodes'][f'{i["strategy"]}/{i["repeat"]}']['stages']
        old,new=stages['original'],stages[i['stage']]
        used={c.get('semantic_identity') for c in row['raw_tool_trace']}
        related=[e for e in old['experience_state']['memories'] if used & set(e['value']['tool_ids'])]
        after={e['id']:e for e in new['experience_state']['memories']}
        preserved=bool(related) and all(e==after.get(e['id']) for e in related)
        from custom.agents.tool_feedback import reported_error
        errors=[{'tool':c.get('semantic_identity'),'feedback':c.get('harness_schema_feedback',[])}
                for c in row['raw_tool_trace'] if reported_error(c.get('semantic_identity'),c.get('response',{}))]
        result.append({'trajectory':key,'tf':row['score']['task_fulfillment'],
            'no_update_tf':baseline['score']['task_fulfillment'],
            'called_tool_contracts_unchanged':all(old['knowledge'].get(k)==new['knowledge'].get(k) for k in used),
            'related_experience_preserved':preserved,'tool_errors':errors,
            'assessment':'execution_error_despite_preserved_related_knowledge' if preserved else 'candidate_requires_counterfactual'})
    return result


def isolation_probe(config, selected, snapshot, emit):
    """Two simultaneously live private servers; a real write in one must not reach the other."""
    servers={ALIASES.get(s,s) for t in selected for s in t['servers']}
    for server in servers:
        policy=policy_for(server,config)
        if policy['concurrency']!='private' or policy.get('external_mutation'):
            raise ValueError('Counterfactual permits only reviewed private local backends')
    from custom.agents.tool_results import raw_result
    with ExitStack() as stack:
        runtimes=[stack.enter_context(runtime_for(config,STAGE,servers,selected,None,emit)) for _ in range(2)]
        if len({str(r.workspace) for r in runtimes})!=2 or len({r.url for r in runtimes})!=2:
            raise ValueError('Isolation probe reused a workspace or endpoint')
        for runtime in runtimes:
            if adapters.semantic(runtime.catalog)!={k:v for k,v in adapters.semantic(snapshot['catalog']).items() if v['server'] in servers}:
                raise ValueError('Late backend differs from the frozen source catalog')
        marker='independent-counterfactual-isolation-probe'
        if 'mcp-shrimp-task-manager' not in servers:
            tool = 'mcp-tasks::tasks_setup'
            if tool not in runtimes[0].catalog:
                tool = '@modelcontextprotocol/server-filesystem::write_file'
            if tool not in runtimes[0].catalog:
                raise ValueError('No reviewed writable backend for the isolation probe')
            targets = [r.workspace / '.counterfactual-isolation.md' for r in runtimes]
            if any(p.exists() for p in targets):
                raise ValueError('Probe marker already exists')
            arguments = ({'source_path':targets[0].as_posix()} if tool.startswith('mcp-tasks::') else
                         {'path':targets[0].as_posix(),'content':marker})
            response = raw_result(runtimes[0].call(runtimes[0].catalog[tool]['remote_name'],arguments))
            if response.get('isError') or not targets[0].is_file() or targets[1].exists():
                raise ValueError('A private task-source write did not remain isolated')
            return {'status':'passed','workspace_paths':[str(r.workspace) for r in runtimes],
                'endpoints':[r.url for r in runtimes],'distinct_workspaces':True,'distinct_endpoints':True,
                'write_visible_only_to_owner':True,'probe_response':response,
                'scope':'Private task-source workspace/process/port isolation; not an OS security sandbox.'}
        def tasks(runtime):
            return [t for p in (runtime.workspace/'shrimp-data').rglob('tasks.json') for t in read_json(p).get('tasks',[])]
        if any(tasks(r) for r in runtimes):raise ValueError('Probe task state was not initially empty')
        tool='mcp-shrimp-task-manager::split_tasks'
        args={'updateMode':'append','tasksRaw':json.dumps([{'name':marker,
            'description':'Create a temporary task used only to verify private backend state isolation.',
            'implementationGuide':'This temporary task is not part of the benchmark. Verify the stored marker only in its owning private runtime.',
            'verificationCriteria':'The marker is present in the first runtime and absent in the second runtime.',
            'dependencies':[],'relatedFiles':[]}])}
        response=raw_result(runtimes[0].call(runtimes[0].catalog[tool]['remote_name'],args))
        if response.get('isError') or marker not in {t['name'] for t in tasks(runtimes[0])} or tasks(runtimes[1]):
            raise ValueError('A private backend write did not remain isolated')
        return {'status':'passed','workspace_paths':[str(r.workspace) for r in runtimes],
                'endpoints':[r.url for r in runtimes],'distinct_workspaces':True,'distinct_endpoints':True,
                'write_visible_only_to_owner':True,'probe_response':response,
                'scope':'Private workspace/process/port isolation; not an OS security sandbox for arbitrary tools.'}


def report(store):
    from .memory_ablation import report_pilot
    from .results import SCORES
    inspected=report_pilot(store,entries=store.manifest['diagnostic']['entry_dependencies'])
    output={'protocol':PROTOCOL,'status':store.records['status'],'conditions':{},'rows':inspected['tasks'],
            'interpretation':'Exploratory frozen-snapshot intervention on selected regressions. No automatic causal label or population claim.'}
    active_conditions=tuple(store.manifest['diagnostic'].get('conditions',CONDITIONS))
    rows=list(store.records['trajectories'].values())
    ordered=sorted(rows,key=lambda r:(r['identity']['task_id'],r['identity']['repeat']))
    for item,row in zip(output['rows'],ordered):item['condition']=row['identity']['strategy']
    for condition in active_conditions:
        group=[r for r in rows if r['identity']['strategy']==condition];good=[r for r in group if r.get('score') is not None]
        from custom.agents.tool_feedback import reported_error
        errors=[c for r in group for c in r['raw_tool_trace'] if reported_error(c.get('semantic_identity'),c.get('response',{}))]
        output['conditions'][condition]={'planned':len(group),'scored':len(good),
            'means':{m:sum(r['score'][m] for r in good)/len(good) if good else None for m in SCORES},
            'completed_agents':sum(r['agent_status']=='completed' for r in group),
            'agents_with_tool_calls':sum(bool(r['raw_tool_trace']) for r in group),
            'valid_judge_slots':sum(a['status']=='completed' for r in group for a in r['judge_attempts']),
            'tool_error_responses':len(errors),
            'unsupported_tags_calls':sum(c.get('semantic_identity')=='mcp-shrimp-task-manager::plan_task' and
                any(f.get('constraint')=='additionalProperties' and 'tags' in f.get('message','') for f in c.get('harness_schema_feedback',[])) for c in errors)}
    triples=[]
    for task,repeat in sorted({(r['identity']['task_id'],r['identity']['repeat']) for r in rows}):
        triple={c:store.records['trajectories'][identity(c,STAGE,task,repeat)] for c in active_conditions}
        if all(r.get('score') is not None for r in triple.values()):
            triples.append({'task_id':task,'repeat':repeat,'tf':{c:r['score']['task_fulfillment'] for c,r in triple.items()}})
    output['matched_triples']=triples
    output['fully_judged_matched_triples']=[t for t in triples if all(
        all(a['status']=='completed' for a in store.records['trajectories'][identity(c,STAGE,t['task_id'],t['repeat'])]['judge_attempts'])
        for c in active_conditions)]
    if len(active_conditions)==2:
        output['matched_pairs']=triples
        differences=[t['tf']['fr_all']-t['tf']['fr_changed_only'] for t in triples]
        output['mean_paired_tf_fr_minus_retained']=sum(differences)/len(differences) if differences else None
    output['same_callable_tools']=all(len({r.get('counterfactual_callable_sha256') for r in rows
        if (r['identity']['task_id'],r['identity']['repeat'])==(task,repeat)})==1
        for task,repeat in {(r['identity']['task_id'],r['identity']['repeat']) for r in rows})
    output['runtime_ids']=[e['runtime_id'] for e in store.records['events'] if e['kind']=='runtime_prepared']
    output['distinct_runtime_ids']=len(output['runtime_ids'])==len(set(output['runtime_ids']))
    if store.manifest['diagnostic'].get('actor_only'):
        output['evaluation'] = 'Actor-only diagnostic; no Judge calls or replacement benchmark scores.'
        for condition in active_conditions:
            output['conditions'][condition]['workspace_observations'] = sum(bool(r.get('workspace_observations'))
                for r in rows if r['identity']['strategy'] == condition)
    return output


def run(config, task_list, source, task_ids, snapshot_repeat=0, parallel=False, workers=1, probe_only=False,
        retained_control_only=False, scoped_memory=False, repeats=3, connect_retries=0, current_clock=False,
        actor_only=False, observe_workspace=False, restore_entries=None, paired_paths=False, input_anchor=None,
        greedy_confirmation=False, include_order_control=False, anchor_trajectory=None):
    if type(workers) is not int or workers < 1:
        raise ValueError('workers must be a positive integer')
    if type(repeats) is not int or repeats not in (1,3,10):
        raise ValueError('Use one pilot repeat, three quick repeats, or ten confirmation repeats')
    if paired_paths and parallel:
        raise ValueError('Identical paired paths require serial fresh backends')
    if include_order_control and not retained_control_only:
        raise ValueError('Order control requires the two-arm retained-knowledge comparison')
    if anchor_trajectory and (not input_anchor or greedy_confirmation):
        raise ValueError('Native trajectory anchors require an input anchor and original temperature')
    source=(ROOT/Path(source)).resolve();manifest=read_json(source/'experiment.json');historical=read_json(source/'records.json')
    if manifest.get('source_archive_sha256') and file_hash(source/'inputs/source.zip')!=manifest['source_archive_sha256']:
        raise ValueError('Archived source ZIP checksum mismatch')
    if any(config.get(k)!=manifest['settings'].get(k) for k in FIXED):
        raise ValueError('Keep the archived model, decoding, memory, runtime, request budget and Judge settings')
    if not task_ids or not set(task_ids)<={t['idx'] for t in task_list}:
        raise ValueError('Diagnostic task IDs must belong to the frozen original selection')
    selected=[next(t for t in task_list if t['idx']==i) for i in task_ids]
    archived={t['idx']:t for t in manifest['task_definitions']}
    if len(set(task_ids))!=len(task_ids) or any(t!=archived.get(t['idx']) for t in selected):
        raise ValueError('Diagnostic tasks must be unchanged members of the original selection')
    variants,snapshot,changed=conditions(historical,snapshot_repeat,restore_entries)
    from .memory import load
    if load(config)['memory_sha256']!=variants['frozen_k0'][0]['memory_sha256']:
        raise ValueError('Configured initial knowledge differs from the archived K0')
    if retained_control_only:
        variants={c:variants[c] for c in CONDITIONS[:2]}
    if include_order_control:
        variants['fr_order_only'] = order_control(variants['fr_all'])
    active_conditions=tuple(variants)
    callable_hashes={}
    for task in selected:
        scopes={c:scope(k,task) for c,(_,k) in variants.items()}
        if any(v!=scopes['fr_all'] for v in scopes.values()):
            raise ValueError('This diagnostic requires unchanged callable tools across every condition')
        callable_hashes[task['idx']]=digest(scopes['fr_all'])
    effective=deepcopy(config);effective['strategies']=['no_update'];effective['agent_repeats']=repeats
    if greedy_confirmation:
        effective['agent_temperature']=0
    if type(connect_retries) is not int or not 0 <= connect_retries <= 2:
        raise ValueError('Connection retries must be zero, one or two')
    if connect_retries:
        effective['runtime']['model_connect_retries']=connect_retries
    from custom.utils.test_utils import offset_date
    prompt_time=str(offset_date(0)) if current_clock else manifest['prompt_time']
    if scoped_memory:
        effective['memory']['profile']='all'
    anchor = None
    if input_anchor:
        if not paired_paths or parallel:
            raise ValueError('Anchored inputs require serial paired paths')
        input_anchor=(ROOT/Path(input_anchor)).resolve()
        anchor=read_json(input_anchor/'experiment.json')
        diagnostic=anchor.get('diagnostic',{})
        if anchor_trajectory:
            anchor_records=read_json(input_anchor/'records.json')
            native_directory=native_anchor_directory(anchor,anchor_records,anchor_trajectory,source,
                file_hash(source/'records.json'),task_ids,snapshot_repeat,config,variants['fr_all'][0])
        elif (anchor.get('harness_protocol')!=PROTOCOL or
                Path(diagnostic.get('source_experiment','')).resolve()!=source or
                diagnostic.get('source_records_sha256')!=file_hash(source/'records.json') or
                diagnostic.get('snapshot_repeat')!=snapshot_repeat or
                any(anchor['settings'].get(k)!=effective.get(k) for k in FIXED
                    if not (greedy_confirmation and k=='agent_temperature'))):
            raise ValueError('Input anchor must use the same donor, snapshot, model and settings')
        anchored_tasks={t['idx']:t for t in anchor['task_definitions']}
        if any(anchored_tasks.get(t['idx'])!=t for t in selected):
            raise ValueError('Anchored questions must match the original task definitions')
        prompt_time=anchor['prompt_time']
    from .experience_state import as_artifact
    from .memory import render
    visible={}
    for task in selected:
        required={ALIASES.get(s,s) for s in task['servers']}
        visible[str(task['idx'])]={}
        for condition,(state,knowledge) in variants.items():
            tools,_=adapters.agent_tools(knowledge,snapshot['catalog'],required)
            context,exposure=render(effective,knowledge,required,Path('DIAGNOSTIC_WORKSPACE'),
                api_names={t['meta']['benchmark_semantic_identity']:t['name'] for t in tools},artifact=as_artifact(state,knowledge))
            visible[str(task['idx'])][condition]={'context_sha256':digest(context),'selected_ids':exposure['selected_ids']}
            if condition == 'fr_all':
                original_context=context
            if condition == 'fr_order_only':
                original_lines=original_context.splitlines();control_lines=context.splitlines()
                def decoded(lines):
                    return [json.loads(line) if line.startswith('{') else line for line in lines]
                if context==original_context or len(context)!=len(original_context) or decoded(control_lines)!=decoded(original_lines):
                    raise ValueError('Order-only control must change presentation with identical content and length')
    expected=fingerprints(effective)
    import uuid
    directories = {f'{task["idx"]}/{repeat}': str(ROOT / '.runtime/r' / uuid.uuid4().hex[:16])
                   for task in selected for repeat in range(repeats)} if paired_paths else {}
    if anchor:
        if anchor_trajectory:
            directories={f'{task["idx"]}/{repeat}':str(native_directory)
                         for task in selected for repeat in range(repeats)}
        else:
            frozen=anchor['diagnostic']['paired_runtime_directories']
            directories={f'{task["idx"]}/{repeat}':frozen[f'{task["idx"]}/0']
                         for task in selected for repeat in range(repeats)}
    archived_metadata=None
    if anchor_trajectory and native_directory.exists():
        metadata_names={'admin','clientSessions','runtime.owner','sessions','mcp.json','presets.json',
                        'runtime-identity.json','server.pid','service.log','template-context-capability.json'}
        import stat
        if any(p.name not in metadata_names or p.is_symlink() or
               getattr(p.lstat(),'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0)
               for p in native_directory.iterdir()):
            raise ValueError('Native anchor directory contains state beyond stopped service metadata')
        if (native_directory/'server.pid').is_file():
            import socket
            service=read_json(native_directory/'server.pid')
            if Path(service['configDir']).resolve()!=native_directory:
                raise ValueError('Stopped service metadata belongs to another directory')
            with socket.socket() as probe:
                probe.settimeout(.5)
                if probe.connect_ex(('127.0.0.1',service['port']))==0:
                    raise ValueError('Native anchor service endpoint is still active')
        archived_metadata=native_directory.with_name(uuid.uuid4().hex[:16])
        if archived_metadata.parent.resolve() != (ROOT/'.runtime/r').resolve() or archived_metadata.exists():
            raise ValueError('Invalid stopped metadata archive target')
        native_directory.rename(archived_metadata)
    path=create(effective,selected,expected,parallel,workers)
    with writer_lock(path):
        store=Store(path);rows={}
        for row in store.records['trajectories'].values():
            if row['identity']['stage']!=STAGE:continue
            for condition in active_conditions:
                clone=deepcopy(row);clone['identity']['strategy']=condition;clone.pop('shared_from',None)
                clone['counterfactual_callable_sha256']=callable_hashes[clone['identity']['task_id']]
                rows[identity(condition,STAGE,clone['identity']['task_id'],clone['identity']['repeat'])]=clone
        store.records.update(status='running',trajectories=rows,episodes={},initial_snapshot=deepcopy(historical['initial_snapshot']))
        store.manifest.update(harness_protocol=PROTOCOL,purpose='frozen_late_memory_counterfactual',
            shared_early=None,prompt_time=prompt_time,task_annotations={},
            logical_conditions=[r['identity'] for r in rows.values()],planned_jobs=[r['identity'] for r in rows.values()],
            diagnostic={'source_experiment':str(source),'source_records_sha256':file_hash(source/'records.json'),
                'snapshot_repeat':snapshot_repeat,'stage':STAGE,'conditions':list(active_conditions),'task_ids':task_ids,
                'scoped_memory':scoped_memory,'trajectory_repeats':repeats,'visible_memory_inputs':visible,
                'actor_only':actor_only,'observe_workspace':observe_workspace,'restored_entry_ids':restore_entries,
                'paired_runtime_directories':directories,
                'input_anchor':str(input_anchor) if anchor else None,
                'input_anchor_manifest_sha256':file_hash(input_anchor/'experiment.json') if anchor else None,
                'anchor_trajectory':anchor_trajectory,
                'input_anchor_records_sha256':file_hash(input_anchor/'records.json') if anchor_trajectory else None,
                'archived_stopped_metadata':str(archived_metadata) if archived_metadata else None,
                'order_control':'Reverse JSON object keys only; equal content, equal character length, unchanged list order' if include_order_control else None,
                'greedy_confirmation':greedy_confirmation,
                'source_actor_temperature':config['agent_temperature'],
                'pre_http_connect_retries':connect_retries,'clock':'current batch start' if current_clock else 'archived source',
                'fixed_original_selection':manifest['selected_ids'],'affected_entry_ids':changed,
                'paid_update_calls':0,'probe_only':probe_only,
                'entry_dependencies':[{'id':e['id'],'value':{'tool_ids':e['value']['tool_ids']}} for e in variants['fr_all'][0]['memories']],
                'condition_hashes':{c:{'memory_sha256':s['memory_sha256'],'reference_catalog_sha256':digest(k)} for c,(s,k) in variants.items()},
                'order':'Rotate leading condition per task and repeat; all use the same account assignment.'},
            analysis={'comparison':'Same callable Late tools; full FR vs retained unaffected knowledge vs initial K0. No ECS.'})
        atomic_json(path/'experiment.json',store.manifest);atomic_json(path/'inputs/counterfactual-snapshots.json',variants)
        atomic_json(path/'candidate-review.json',{'source':str(source),'candidates':screening(historical)})
        store.save();print('Counterfactual:',path,flush=True)
        try:
            if effective['mode']=='live':
                proof=isolation_probe(effective,selected,snapshot,store.apply)
                store.manifest['isolation']=proof;atomic_json(path/'experiment.json',store.manifest)
            if not probe_only:
                jobs=[]
                for repeat in range(repeats):
                    for position,task in enumerate(selected):
                        offset=(repeat+position)%len(active_conditions)
                        for condition in active_conditions[offset:]+active_conditions[:offset]:
                            state,knowledge=variants[condition]
                            jobs.append({'config':effective,'tasks':selected,'task':task,'stage':STAGE,
                                'strategy':condition,'repeat':repeat,'snapshot':deepcopy(snapshot),
                                'knowledge':deepcopy(knowledge),'experience_state':deepcopy(state),'records':rows,
                                'initial_snapshot':deepcopy(historical['initial_snapshot']),'prompt_time':prompt_time,
                                'phase':'agent' if actor_only else None,'observe_workspace':observe_workspace,
                                'actor_only':actor_only,'controlled_runtime_directory':directories.get(f'{task["idx"]}/{repeat}')})
                if parallel:
                    from .parallel import supervise_stage
                    supervise_stage(jobs,store,workers,effective['runtime']['shutdown_timeout'])
                else:
                    for job in jobs:run_trajectory(job,store.apply)
            actual=fingerprints(effective)
            if actual!=expected:raise ValueError('Diagnostic source/configuration drifted')
            store.manifest['fixture_unchanged']=actual['sources']['fixtures']==expected['sources']['fixtures']
            atomic_json(path/'experiment.json',store.manifest)
            if file_hash(source/'records.json')!=store.manifest['diagnostic']['source_records_sha256']:
                raise ValueError('Historical source changed')
            rows=list(store.records['trajectories'].values())
            failed=any(r['agent_status']!='completed' if actor_only else
                r['status']!='completed' or r.get('score') is None for r in rows)
            judge_warnings=not actor_only and any(a['status']!='completed' for r in rows for a in r['judge_attempts'])
            store.records['status']=('probe_passed' if probe_only else 'completed_with_failures' if failed
                                     else 'completed_with_warnings' if judge_warnings else 'completed')
        except BaseException as exc:
            store.records['status']='failed';store.event('counterfactual_failure',error=safe_error(exc));raise
        finally:
            store.save();result=report(store);atomic_json(path/'counterfactual.json',result)
        return path,result
