"""Check an archived FR restriction against real existing-name dependency resolution."""
from copy import deepcopy
import json

from custom.agents.tool_results import raw_result
from .core import runtime_for
from .experience_state import validate_state
from .selection import read_json

SERVER = 'mcp-shrimp-task-manager'
ENTRY = '2f1905b241c99bb6930cbd70'
TOOLS = {SERVER + '::split_tasks'}
BAD_RULE = 'Reference existing tasks only by IDs returned from successful tool outputs.'
FACT = 'Reference an existing prerequisite by its exact task name or an actual task ID; never invent an ID.'
PREREQUISITE = {'id': 'a2d07312-0acf-49a7-84a2-451540a7cb1e', 'name': 'Parse source packets',
    'description': 'Parse input packets before checksum validation.', 'status': 'completed',
    'dependencies': [], 'relatedFiles': [], 'implementationGuide': 'Parse each input packet into fields.',
    'verificationCriteria': 'Every valid packet has parsed fields.',
    'createdAt': '2026-10-01T00:00:00.000Z', 'updatedAt': '2026-10-01T00:00:00.000Z'}
FIXTURE = {'tasks': [PREREQUISITE]}
NEW_NAME = 'Review packet checksum'
CASE = {'id': 'append-existing-dependency', 'question':
    'Append one pending task named "Review packet checksum" to validate packet checksums. '
    'It must depend on the existing completed task named "Parse source packets". '
    'Do not recreate or alter the existing task, remove existing tasks, or omit the prerequisite. '
    'Include a concrete implementation guide and verification criteria, then confirm what was created. '
    'This integration exposes only the task creation endpoint.'}


def prepare(source):
    stages = read_json(source / 'records.json')['episodes']['full_rewrite/2']['stages']
    old, late = stages['original'], stages['iter5']
    for stage in (old, late):
        validate_state(stage['experience_state'], stage['knowledge'])
    if any(old['knowledge'][k] != late['knowledge'][k] for k in TOOLS):
        raise ValueError('The dependency probe requires an unchanged split_tasks contract')
    entries = {a: deepcopy(next(e for e in s['experience_state']['memories'] if e['id'] == ENTRY))
               for a, s in (('original_rule', old), ('archived_fr', late))}
    rewritten = entries['archived_fr']['value']
    if BAD_RULE not in rewritten['actions']:
        raise ValueError('The archived restrictive FR rule was not found')
    entries['fr_restore_fact'] = deepcopy(entries['archived_fr'])
    entries['fr_restore_fact']['value']['actions'] = [FACT if a == BAD_RULE else a for a in rewritten['actions']]
    return entries, late


def evaluate(trace, observations, answer, completed):
    final = observations[-1] if observations else {'tasks': []}
    previous = [t for t in final.get('tasks', []) if t['id'] == PREREQUISITE['id']]
    new = [t for t in final.get('tasks', []) if t['name'] == NEW_NAME and t['id'] != PREREQUISITE['id']]
    preserved = bool(observations) and all(
        [t for t in s.get('tasks', []) if t['id'] == PREREQUISITE['id']] == [PREREQUISITE] for s in observations)
    graph = len(new) == 1 and new[0].get('dependencies') == [{'taskId': PREREQUISITE['id']}]
    stored = bool(new) and new[0].get('status') == 'pending' and bool(new[0].get('implementationGuide')) and bool(new[0].get('verificationCriteria'))
    calls = [c['tool_call_id'] for c in trace if c.get('semantic_identity') in TOOLS and not c['response'].get('isError')]
    backend_success = len(final.get('tasks', [])) == 2 and previous == [PREREQUISITE] and preserved and graph and stored and bool(calls)
    return {'success': bool(backend_success) if completed else None, 'backend_success': bool(backend_success),
        'state_unchanged_throughout_observations': bool(observations) and all(s == FIXTURE for s in observations),
        'required_invariants_preserved': preserved and (not new or graph),
        'prerequisite_preserved': preserved, 'correct_dependency': bool(graph), 'new_task_count': len(new),
        'successful_creation_call_ids': calls}


def probe(config, emit):
    from .effect_boundary import seed, task_state
    evidence = []
    for reference in (PREREQUISITE['name'], PREREQUISITE['id']):
        with runtime_for(config, 'iter5', [SERVER], [], None, emit) as runtime:
            seed(runtime, FIXTURE)
            args = {'updateMode': 'append', 'tasksRaw': json.dumps([{'name': NEW_NAME,
                'description': 'Validate the checksum of parsed source packets.', 'implementationGuide': 'Compute and compare packet checksums.',
                'verificationCriteria': 'Invalid checksums are rejected.', 'dependencies': [reference], 'relatedFiles': []}])}
            response = raw_result(runtime.call(runtime.catalog[SERVER + '::split_tasks']['remote_name'], args))
            trace = [{'tool_call_id': 'mechanism', 'semantic_identity': SERVER + '::split_tasks', 'response': response}]
            after = task_state(runtime)
            outcome = evaluate(trace, [FIXTURE, after], '', True)
            if not outcome['success']:
                raise ValueError('Existing-name/ID dependency behavior was not verified')
            evidence.append({'reference': reference, 'arguments': args, 'response': response, 'before': FIXTURE, 'after': after, 'outcome': outcome})
    return evidence
