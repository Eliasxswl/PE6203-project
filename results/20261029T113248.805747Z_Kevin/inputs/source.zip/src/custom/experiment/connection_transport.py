"""Optional pre-HTTP connection recovery; never retry a completed model request."""
import urllib.request

import httpx

from .results import safe_error


def client(timeout, retries, emit=None):
    if type(retries) is not int or not 0 <= retries <= 2:
        raise ValueError('Connection retries must be an integer from zero to two')
    if any(v for k, v in urllib.request.getproxies().items() if k in ('http', 'https', 'all')):
        raise ValueError('Explicit connection recovery must not bypass a configured proxy')

    def attach(request):
        previous = request.extensions.get('trace')
        attempts = 0

        def trace(name, info):
            nonlocal attempts
            if previous:
                previous(name, info)
            if name == 'connection.connect_tcp.started':
                attempts += 1
                if emit:
                    emit({'kind': 'transport_connect_started', 'attempt': attempts, 'host': request.url.host,
                          'pre_http_request': True})
            elif name in ('connection.connect_tcp.failed', 'connection.start_tls.failed') and emit:
                emit({'kind': 'transport_connect_failed', 'attempt': attempts, 'host': request.url.host,
                      'pre_http_request': True, 'error': safe_error(info['exception'])})

        request.extensions['trace'] = trace

    return httpx.Client(transport=httpx.HTTPTransport(retries=retries), timeout=timeout,
                        event_hooks={'request': [attach]})
